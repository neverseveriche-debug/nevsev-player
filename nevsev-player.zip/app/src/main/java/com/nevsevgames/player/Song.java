package com.nevsevgames.player;

import android.net.Uri;

final class Song {
    final long id;
    final String title;
    final String artist;
    final long durationMs;
    final Uri uri;

    Song(long id, String title, String artist, long durationMs, Uri uri) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.durationMs = durationMs;
        this.uri = uri;
    }

    static String formatTime(long ms) {
        long totalSeconds = Math.max(0, ms) / 1000;
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;
        if (hours > 0) {
            return String.format(java.util.Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds);
        }
        return String.format(java.util.Locale.ROOT, "%d:%02d", minutes, seconds);
    }
}
