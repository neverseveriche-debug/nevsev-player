package com.nevsevgames.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Reproduce la musica en segundo plano y muestra los controles en la notificacion. */
public class MusicService extends Service {

    public interface Listener {
        void onPlayerChanged();
    }

    public static final int REPEAT_OFF = 0;
    public static final int REPEAT_ALL = 1;
    public static final int REPEAT_ONE = 2;

    private static final String ACTION_TOGGLE = "com.nevsevgames.player.TOGGLE";
    private static final String ACTION_NEXT = "com.nevsevgames.player.NEXT";
    private static final String ACTION_PREV = "com.nevsevgames.player.PREV";
    private static final String ACTION_CLOSE = "com.nevsevgames.player.CLOSE";
    private static final String CHANNEL_ID = "playback";
    private static final int NOTIFICATION_ID = 1;
    private static final int MAX_CONSECUTIVE_ERRORS = 5;

    public final class LocalBinder extends Binder {
        public MusicService getService() {
            return MusicService.this;
        }
    }

    private final IBinder binder = new LocalBinder();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private List<Song> queue = new ArrayList<>();
    private int index = -1;
    private MediaPlayer player;
    private boolean prepared;
    private boolean playRequested;
    private boolean resumeOnFocusGain;
    private boolean foreground;
    private boolean noisyRegistered;
    private int consecutiveErrors;
    private int artToken;
    private Bitmap art;
    private boolean shuffle;
    private int repeatMode = REPEAT_OFF;
    private Listener listener;

    private NotificationManager notificationManager;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private MediaSession session;
    private SharedPreferences prefs;

    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            pause(); // Se desconectaron los auriculares: no sonar por el altavoz.
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("player", MODE_PRIVATE);
        shuffle = prefs.getBoolean("shuffle", false);
        repeatMode = prefs.getInt("repeat", REPEAT_OFF);

        notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW));

        audioManager = getSystemService(AudioManager.class);
        focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(audioAttributes())
                .setOnAudioFocusChangeListener(this::onFocusChange, mainHandler)
                .build();

        session = new MediaSession(this, "NevsevPlayer");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(); }
            @Override public void onSkipToPrevious() { previous(); }
            @Override public void onSeekTo(long pos) { seekTo((int) pos); }
            @Override public void onStop() { close(); }
        });
        session.setSessionActivity(openAppIntent());
        session.setActive(true);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_TOGGLE.equals(action)) togglePlayPause();
        else if (ACTION_NEXT.equals(action)) next();
        else if (ACTION_PREV.equals(action)) previous();
        else if (ACTION_CLOSE.equals(action)) close();
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (!isPlaying()) close();
    }

    @Override
    public void onDestroy() {
        unregisterNoisy();
        releasePlayer();
        audioManager.abandonAudioFocusRequest(focusRequest);
        session.release();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------- API usada por la pantalla ----------

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setQueue(List<Song> songs) {
        Song current = getCurrentSong();
        queue = new ArrayList<>(songs);
        index = -1;
        if (current != null) {
            for (int i = 0; i < queue.size(); i++) {
                if (queue.get(i).id == current.id) {
                    index = i;
                    break;
                }
            }
        }
        changed();
    }

    public void playSong(Song song) {
        for (int i = 0; i < queue.size(); i++) {
            if (queue.get(i).id == song.id) {
                play(i);
                return;
            }
        }
    }

    public void togglePlayPause() {
        if (isPlaying()) pause();
        else resume();
    }

    public void next() {
        if (queue.isEmpty()) return;
        play(pickNext());
    }

    public void previous() {
        if (queue.isEmpty()) return;
        if (getPosition() > 3000) {
            seekTo(0);
            return;
        }
        play(index <= 0 ? queue.size() - 1 : index - 1);
    }

    public void seekTo(int ms) {
        if (player != null && prepared) {
            player.seekTo(ms);
            updateSessionState();
        }
    }

    public void toggleShuffle() {
        shuffle = !shuffle;
        prefs.edit().putBoolean("shuffle", shuffle).apply();
        changed();
    }

    public void cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3;
        prefs.edit().putInt("repeat", repeatMode).apply();
        changed();
    }

    public boolean isShuffle() { return shuffle; }
    public int getRepeatMode() { return repeatMode; }
    public Bitmap getArt() { return art; }

    /** Tambien es true mientras la cancion se esta cargando. */
    public boolean isPlaying() {
        return player != null && (prepared ? player.isPlaying() : playRequested);
    }

    public Song getCurrentSong() {
        return index >= 0 && index < queue.size() ? queue.get(index) : null;
    }

    public int getPosition() {
        return player != null && prepared ? player.getCurrentPosition() : 0;
    }

    public int getDuration() {
        if (player != null && prepared) return player.getDuration();
        Song song = getCurrentSong();
        return song == null ? 0 : (int) song.durationMs;
    }

    // ---------- Reproduccion ----------

    private void play(int newIndex) {
        if (newIndex < 0 || newIndex >= queue.size()) return;
        index = newIndex;
        releasePlayer();
        requestFocus();
        registerNoisy();
        playRequested = true;
        resumeOnFocusGain = false;

        Song song = queue.get(index);
        player = new MediaPlayer();
        player.setAudioAttributes(audioAttributes());
        player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
        player.setOnPreparedListener(mp -> {
            prepared = true;
            consecutiveErrors = 0;
            if (playRequested) mp.start();
            updateAll();
        });
        player.setOnCompletionListener(mp -> onSongFinished());
        player.setOnErrorListener((mp, what, extra) -> {
            handleError();
            return true;
        });
        try {
            player.setDataSource(this, song.uri);
            player.prepareAsync();
        } catch (Exception e) {
            // Se aplaza para no volver a entrar en play() mientras se ejecuta.
            mainHandler.post(this::handleError);
        }
        loadArt(song);
        updateAll();
    }

    private void resume() {
        if (player == null) {
            if (getCurrentSong() != null) play(index);
            else if (!queue.isEmpty()) play(0);
            return;
        }
        requestFocus();
        registerNoisy();
        playRequested = true;
        resumeOnFocusGain = false;
        if (prepared) player.start();
        updateAll();
    }

    private void pause() {
        pauseInternal();
        resumeOnFocusGain = false;
        audioManager.abandonAudioFocusRequest(focusRequest);
    }

    private void pauseInternal() {
        playRequested = false;
        if (player != null && prepared && player.isPlaying()) player.pause();
        unregisterNoisy();
        updateAll();
    }

    private void close() {
        pause();
        releasePlayer();
        foreground = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        notificationManager.cancel(NOTIFICATION_ID);
        changed();
        stopSelf();
    }

    private void onSongFinished() {
        if (repeatMode == REPEAT_ONE) {
            play(index);
        } else if (!shuffle && repeatMode == REPEAT_OFF && index == queue.size() - 1) {
            // Fin de la lista: deja la ultima cancion lista y en pausa.
            playRequested = false;
            player.seekTo(0);
            unregisterNoisy();
            updateAll();
        } else {
            play(pickNext());
        }
    }

    private int pickNext() {
        int size = queue.size();
        if (shuffle && size > 1) {
            int candidate;
            do {
                candidate = random.nextInt(size);
            } while (candidate == index);
            return candidate;
        }
        return (index + 1) % size;
    }

    /** Salta archivos danados, sin quedarse en un bucle si fallan todos. */
    private void handleError() {
        consecutiveErrors++;
        releasePlayer();
        if (consecutiveErrors < MAX_CONSECUTIVE_ERRORS && queue.size() > 1) {
            play(pickNext());
        } else {
            consecutiveErrors = 0;
            playRequested = false;
            unregisterNoisy();
            updateAll();
        }
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
        prepared = false;
    }

    private AudioAttributes audioAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
    }

    private void requestFocus() {
        audioManager.requestAudioFocus(focusRequest);
    }

    private void onFocusChange(int change) {
        switch (change) {
            case AudioManager.AUDIOFOCUS_LOSS:
                pause();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                boolean wasPlaying = isPlaying();
                pauseInternal();
                resumeOnFocusGain = wasPlaying;
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if (player != null) player.setVolume(0.3f, 0.3f);
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (player != null) player.setVolume(1f, 1f);
                if (resumeOnFocusGain) resume();
                break;
            default:
                break;
        }
    }

    private void registerNoisy() {
        if (!noisyRegistered) {
            registerReceiver(noisyReceiver, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
            noisyRegistered = true;
        }
    }

    private void unregisterNoisy() {
        if (noisyRegistered) {
            unregisterReceiver(noisyReceiver);
            noisyRegistered = false;
        }
    }

    // ---------- Caratula, notificacion y sesion ----------

    private void loadArt(Song song) {
        final int token = ++artToken;
        art = null;
        new Thread(() -> {
            Bitmap bitmap = readEmbeddedArt(song);
            mainHandler.post(() -> {
                if (token == artToken) {
                    art = bitmap;
                    updateAll();
                }
            });
        }).start();
    }

    private Bitmap readEmbeddedArt(Song song) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, song.uri);
            byte[] data = retriever.getEmbeddedPicture();
            if (data == null) return null;
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            while (Math.max(bounds.outWidth, bounds.outHeight) / options.inSampleSize > 512) {
                options.inSampleSize *= 2;
            }
            return BitmapFactory.decodeByteArray(data, 0, data.length, options);
        } catch (Exception e) {
            return null;
        } finally {
            try {
                retriever.release();
            } catch (Exception ignored) {
                // Nada mas que hacer.
            }
        }
    }

    private void updateAll() {
        updateSessionMetadata();
        updateSessionState();
        updateNotification();
        changed();
    }

    private void changed() {
        if (listener != null) listener.onPlayerChanged();
    }

    private void updateSessionMetadata() {
        Song song = getCurrentSong();
        if (song == null) return;
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, song.title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, song.artist)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, getDuration())
                .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art)
                .build());
    }

    private void updateSessionState() {
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                        | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
                        | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO
                        | PlaybackState.ACTION_STOP)
                .setState(isPlaying() ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        getPosition(), isPlaying() ? 1f : 0f)
                .build());
    }

    private void updateNotification() {
        if (getCurrentSong() == null) return;
        Notification notification = buildNotification();
        if (playRequested) {
            try {
                if (!foreground) startForegroundService(new Intent(this, MusicService.class));
                startForeground(NOTIFICATION_ID, notification);
                foreground = true;
            } catch (RuntimeException e) {
                // Android puede negarlo desde segundo plano; la notificacion normal sigue sirviendo.
                notificationManager.notify(NOTIFICATION_ID, notification);
            }
        } else {
            if (foreground) {
                stopForeground(STOP_FOREGROUND_DETACH);
                foreground = false;
            }
            notificationManager.notify(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification() {
        Song song = getCurrentSong();
        boolean playing = isPlaying();
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_music)
                .setContentTitle(song.title)
                .setContentText(song.artist)
                .setContentIntent(openAppIntent())
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(playing)
                .addAction(action(R.drawable.ic_prev, R.string.previous, ACTION_PREV))
                .addAction(playing
                        ? action(R.drawable.ic_pause, R.string.pause, ACTION_TOGGLE)
                        : action(R.drawable.ic_play, R.string.play, ACTION_TOGGLE))
                .addAction(action(R.drawable.ic_next, R.string.next, ACTION_NEXT))
                .addAction(action(R.drawable.ic_close, R.string.close, ACTION_CLOSE))
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
        if (art != null) builder.setLargeIcon(art);
        return builder.build();
    }

    private Notification.Action action(int icon, int title, String actionName) {
        Intent intent = new Intent(this, MusicService.class).setAction(actionName);
        PendingIntent pending = PendingIntent.getService(this, actionName.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(
                Icon.createWithResource(this, icon), getString(title), pending).build();
    }

    private PendingIntent openAppIntent() {
        return PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
