package com.nevsevgames.player;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements MusicService.Listener {

    private static final int REQUEST_PERMISSIONS = 1;

    private final List<Song> allSongs = new ArrayList<>();
    private final List<Song> visibleSongs = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private MusicService service;
    private boolean bound;
    private boolean userSeeking;
    private boolean permissionAlreadyRequested;

    private SongAdapter adapter;
    private EditText search;
    private View emptyView;
    private TextView emptyText;
    private Button grantButton;
    private ImageView art;
    private TextView nowTitle;
    private TextView nowArtist;
    private TextView position;
    private TextView duration;
    private SeekBar seek;
    private ImageButton playPause;
    private ImageButton shuffle;
    private ImageButton repeat;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((MusicService.LocalBinder) binder).getService();
            service.setListener(MainActivity.this);
            service.setQueue(allSongs);
            refreshPlayer();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
        }
    };

    private final Runnable progressTick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        applySystemBarInsets();

        search = findViewById(R.id.search);
        emptyView = findViewById(R.id.empty);
        emptyText = findViewById(R.id.emptyText);
        grantButton = findViewById(R.id.grant);
        art = findViewById(R.id.art);
        nowTitle = findViewById(R.id.nowTitle);
        nowArtist = findViewById(R.id.nowArtist);
        position = findViewById(R.id.position);
        duration = findViewById(R.id.duration);
        seek = findViewById(R.id.seek);
        playPause = findViewById(R.id.playPause);
        shuffle = findViewById(R.id.shuffle);
        repeat = findViewById(R.id.repeat);

        adapter = new SongAdapter();
        ListView list = findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (service != null) service.playSong(visibleSongs.get(pos));
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { applyFilter(); }
        });

        playPause.setOnClickListener(v -> { if (service != null) service.togglePlayPause(); });
        findViewById(R.id.next).setOnClickListener(v -> { if (service != null) service.next(); });
        findViewById(R.id.prev).setOnClickListener(v -> { if (service != null) service.previous(); });
        shuffle.setOnClickListener(v -> { if (service != null) service.toggleShuffle(); });
        repeat.setOnClickListener(v -> { if (service != null) service.cycleRepeat(); });
        grantButton.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", getPackageName(), null))));

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser) position.setText(Song.formatTime(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                userSeeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                userSeeking = false;
                if (service != null) service.seekTo(bar.getProgress());
            }
        });

        bound = bindService(new Intent(this, MusicService.class), connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStart() {
        super.onStart();
        handler.post(progressTick);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Se repite aqui para ver el permiso concedido desde Ajustes y las canciones nuevas.
        if (hasAudioPermission()) {
            loadSongs();
        } else if (!permissionAlreadyRequested) {
            permissionAlreadyRequested = true;
            requestNeededPermissions();
            showEmptyState();
        } else {
            showEmptyState();
        }
    }

    @Override
    protected void onStop() {
        handler.removeCallbacks(progressTick);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (service != null) service.setListener(null);
        if (bound) unbindService(connection);
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (hasAudioPermission()) loadSongs();
        else showEmptyState();
    }

    @Override
    public void onPlayerChanged() {
        refreshPlayer();
    }

    // ---------- Permisos y biblioteca ----------

    private String audioPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private boolean hasAudioPermission() {
        return checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{audioPermission(), Manifest.permission.POST_NOTIFICATIONS},
                    REQUEST_PERMISSIONS);
        } else {
            requestPermissions(new String[]{audioPermission()}, REQUEST_PERMISSIONS);
        }
    }

    private void loadSongs() {
        allSongs.clear();
        String[] columns = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DURATION
        };
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        try (Cursor cursor = getContentResolver().query(collection, columns,
                MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(0);
                    String artist = cursor.getString(2);
                    if (artist == null || artist.isEmpty() || MediaStore.UNKNOWN_STRING.equals(artist)) {
                        artist = getString(R.string.unknown_artist);
                    }
                    allSongs.add(new Song(id, cursor.getString(1), artist, cursor.getLong(3),
                            ContentUris.withAppendedId(collection, id)));
                }
            }
        }
        if (service != null) service.setQueue(allSongs);
        applyFilter();
    }

    private void applyFilter() {
        String query = search.getText().toString().trim().toLowerCase(Locale.getDefault());
        visibleSongs.clear();
        for (Song song : allSongs) {
            if (query.isEmpty()
                    || song.title.toLowerCase(Locale.getDefault()).contains(query)
                    || song.artist.toLowerCase(Locale.getDefault()).contains(query)) {
                visibleSongs.add(song);
            }
        }
        adapter.notifyDataSetChanged();
        showEmptyState();
    }

    private void showEmptyState() {
        boolean permitted = hasAudioPermission();
        emptyView.setVisibility(permitted && !visibleSongs.isEmpty() ? View.GONE : View.VISIBLE);
        emptyText.setText(permitted ? R.string.no_songs : R.string.no_permission);
        grantButton.setVisibility(permitted ? View.GONE : View.VISIBLE);
    }

    // ---------- Interfaz ----------

    private void refreshPlayer() {
        if (service == null) return;
        Song song = service.getCurrentSong();
        nowTitle.setText(song == null ? getString(R.string.nothing_playing) : song.title);
        nowArtist.setText(song == null ? "" : song.artist);

        boolean playing = service.isPlaying();
        playPause.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        playPause.setContentDescription(getString(playing ? R.string.pause : R.string.play));

        Bitmap cover = service.getArt();
        if (cover != null) {
            art.setScaleType(ImageView.ScaleType.CENTER_CROP);
            art.setImageBitmap(cover);
        } else {
            art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            art.setImageResource(R.drawable.ic_music);
        }

        shuffle.setImageAlpha(service.isShuffle() ? 255 : 90);
        repeat.setImageResource(service.getRepeatMode() == MusicService.REPEAT_ONE
                ? R.drawable.ic_repeat_one : R.drawable.ic_repeat);
        repeat.setImageAlpha(service.getRepeatMode() == MusicService.REPEAT_OFF ? 90 : 255);

        updateProgress();
        adapter.notifyDataSetChanged();
    }

    private void updateProgress() {
        if (service == null || userSeeking) return;
        int total = service.getDuration();
        int current = service.getPosition();
        seek.setMax(total);
        seek.setProgress(current);
        position.setText(Song.formatTime(current));
        duration.setText(Song.formatTime(total));
    }

    /** Android 15 dibuja bajo las barras del sistema: se deja el espacio a mano. */
    private void applySystemBarInsets() {
        if (Build.VERSION.SDK_INT < 30) return;
        View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsets.CONSUMED;
        });
    }

    private final class SongAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleSongs.size(); }
        @Override public Song getItem(int position) { return visibleSongs.get(position); }
        @Override public long getItemId(int position) { return visibleSongs.get(position).id; }

        @Override
        public View getView(int pos, View convertView, ViewGroup parent) {
            View row = convertView != null ? convertView
                    : getLayoutInflater().inflate(R.layout.row_song, parent, false);
            Song song = getItem(pos);
            Song current = service == null ? null : service.getCurrentSong();
            boolean active = current != null && current.id == song.id;

            TextView title = row.findViewById(R.id.title);
            title.setText(song.title);
            title.setTextColor(getColor(active ? R.color.accent : R.color.text));
            ((TextView) row.findViewById(R.id.artist)).setText(song.artist);
            ((TextView) row.findViewById(R.id.time)).setText(Song.formatTime(song.durationMs));
            ((ImageView) row.findViewById(R.id.icon)).setImageTintList(
                    getColorStateList(active ? R.color.accent : R.color.muted));
            return row;
        }
    }
}
